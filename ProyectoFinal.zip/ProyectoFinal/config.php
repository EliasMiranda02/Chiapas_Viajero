<?php
define("urlsite","http://localhost/pruebap/") 
?>