<?php
class IndexModel{
    
}
?>